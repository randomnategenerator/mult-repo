alert("Hello World")
let age = parseInt(prompt("How old are you?"))
document.writeln(`You are ${age} years old!`)